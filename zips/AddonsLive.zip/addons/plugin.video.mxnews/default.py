import sys
import xbmcgui
import xbmcplugin
import urllib
import urllib2
import re
import fileinput

 
addon_handle = int(sys.argv[1])
 
xbmcplugin.setContent(addon_handle, 'movies')

response = urllib2.urlopen('http://goo.gl/IfLjRA')
for lines in response:
    print lines

url = 'ea4c9d2666bc411d8e6777e8a1d2b747'
li = xbmcgui.ListItem('Al-Jazerra English News', iconImage='http://offsite.tv/mx/ch/aje.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)


url = 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/bbc_world/ls_satlink/b_828.m3u8'
li = xbmcgui.ListItem('BBC World News', iconImage='http://offsite.tv/mx/ch/bbc_world_news.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://live.bltvios.com.edgesuite.net/oza2w6q8gX9WSkRx13bskffWIuyf/BnazlkNDpCIcD-QkfyZCQKlRiiFnVa5I/master.m3u8?geo_country=US'
li = xbmcgui.ListItem('Bloomberg', iconImage='http://offsite.tv/mx/ch/bloomburg.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = '0ed1c715dc864ab3912d4015903a3d85.m3u8?pt=1&dt=1&ra=1&code='
li = xbmcgui.ListItem('CCTV English News', iconImage='http://offsite.tv/mx/ch/cctvnews.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = 'http://wpc.c1a9.edgecastcdn.net/hls-live/20C1A9/cnn/ls_satlink/b_828.m3u8'
li = xbmcgui.ListItem('CNN International', iconImage='http://offsite.tv/mx/ch/cnn_international_asia_pacific.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = '6DE1E752A9974A5980166483C8ED6BB8'
li = xbmcgui.ListItem('DWTV', iconImage='http://offsite.tv/mx/ch/dwtv.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = '3F35C4428A0D4004A38FF0ADBA7664F4'
li = xbmcgui.ListItem('EuroNews', iconImage='http://offsite.tv/mx/ch/euro.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = '1e2041858ca543fa90ec95d28197e907'
li = xbmcgui.ListItem('Fox News', iconImage='http://offsite.tv/mx/ch/foxnews.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = '82c764aa2d7f42579348b8717cb5b9a4'
li = xbmcgui.ListItem('France 24 English', iconImage='http://offsite.tv/mx/ch/france24.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = '7f2989e3f87e4efdb36bac56b64dca62'
li = xbmcgui.ListItem('MSNBC News HD', iconImage='http://offsite.tv/mx/ch/msnbc.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = 'http://nhkworldlive-lh.akamaihd.net/i/nhkworld_w@145835/master.m3u8'
li = xbmcgui.ListItem('NHK World News', iconImage='http://offsite.tv/mx/ch/nhk_world.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = '31b003ab7e7749a798fe00424e3dd9ff'
li = xbmcgui.ListItem('Sky News HD', iconImage='http://offsite.tv/mx/ch/skyhd.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

url = '7d1847a9b91246b8af20629bfc24d9da'
li = xbmcgui.ListItem('Zee News', iconImage='http://offsite.tv/mx/ch/znews.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=lines+url, listitem=li)

response.close()

xbmcplugin.endOfDirectory(addon_handle)

# default.py
addon_id="script.icechannel.extn.coolwave"
addon_name="iStream Extension coolwave"

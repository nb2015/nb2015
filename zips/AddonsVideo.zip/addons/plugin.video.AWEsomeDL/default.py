import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import urllib,urllib2,re,sys,string,time,datetime

try:
    try: import urlresolver
    except: raise Exception ('Urlresolver Not Found')
    try:from addon.common.net import Net as net
    except: raise Exception ('Addon.common Not Found')
    try:from addon.common.addon import Addon
    except: raise Exception ('Addon.common Not Found')
    try:from universal import favorites, watchhistory, playbackengine
    except: raise Exception ('Universal  Not Found')
    try:from metahandler import metahandlers
    except: raise Exception ('Metahandler  Not Found')
    try:from BeautifulSoup import BeautifulSoup
    except: raise Exception ('BeautifulSoup4 Not Found')
    try:from sqlite3 import dbapi2 as database
    except: raise Exception ('sqlite3 Not Found')
except Exception, e:
    xbmc.log('ERROR AWEsomeDL: '+str(e))
    dialog = xbmcgui.Dialog()
    dialog.ok('[COLOR red]Failed To Find Needed Modules[/COLOR]','[COLOR red][B]'+str(e)+'[/COLOR][/B]',
              'Please Goto [COLOR green][B]XBMCTALK.COM[/COLOR][/B] For Support')
    sys.exit(0)

addonID = 'plugin.video.AWEsomeDL'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)

fav = favorites.Favorites(addonID, sys.argv)
grab = metahandlers.MetaData()
sys.path.append(xbmc.translatePath(os.path.join( local.getAddonInfo('path'), 'resources', 'lib')))
art = xbmc.translatePath(os.path.join( local.getAddonInfo('path'), 'resources', 'art' ))
BaseUrl = 'http://awesomedl.ru/'

#DB TABLE Thanks to Voinage for the insperation for this
db_dir = os.path.join(xbmc.translatePath("special://database"), 'awesomedl.db')
if not xbmcvfs.exists(os.path.dirname(db_dir)):
    xbmcvfs.mkdirs(os.path.dirname(db_dir))
db = database.connect(db_dir)
db.execute('CREATE TABLE IF NOT EXISTS url_cache (name UNIQUE, url UNIQUE)')#A_Z is the Table name and unique allows you to select and search for it, any of them an be unique 
db.commit()
db.close()

def get(name, url):
    db = database.connect( db_dir )
    cur = db.cursor()
    now = time.time()
    cur.execute('SELECT * FROM url_cache WHERE url = "%s"' %url)
    cached = cur.fetchone()
    if cached:
        db.close()
        return cached
    else:
        addon.log('No cached response. Requesting from internet')
        try: data = net().http_GET(url).content
        except:pass
        sql = 'INSERT OR REPLACE INTO url_cache (name, url) VALUES(?,?)'
        cur.execute(sql, (name, url))
        db.commit()
        db.close()
        return name, url
    
    

def MAIN():
    addDir(100, BaseUrl, '', '', '[COLOR orange][B]Latest Added Shows[/COLOR][/B]',
           os.path.join(art, 'latest.jpg'), 0, True)
    addDir(100, BaseUrl, '', '', '[COLOR orange][B]New Series / Shows[/COLOR][/B]',
           os.path.join(art, 'newshowes.jpg'), 0, True)
    #addDir(mode, BaseUrl, '', '', '[COLOR orange][B]Search[/COLOR][/B]',
    #       os.path.join(art, 'search.jpg'), 0, True)
    addDir(10, 'url', '', '', '[COLOR blue][B]Resolver Settings[/COLOR][/B]',
           os.path.join(art, 'resolve.jpg'), 0, '')





def FindShows(url,name):
    title = name
    soup = BeautifulSoup(net().http_GET(url).content, fromEncoding="UTF-8")
    totalitems = 1
    if 'Latest Added Shows' in name or types:
        pattern = re.compile('post-\d+\s')
        for link in soup.findAll('div', {'class':pattern}):
            a=link.find('h2', {'class' : 'title'})
            url =  a.find('a', href=True)['href']
            image = link.findAll('img')[0].get('src')
            name = CleanName(url)
            totalitems = totalitems+1
            addDir(150, url, name, image+'#'+name, name, image, totalitems, True)
    elif 'New Series' in name or metaname:
        for link in soup.findAll('li', {'id' : "text-7"}):
            for href in link.findAll('a', href=True):
                pattern = '\"(.+?)\"\>(.+?)\<\/a\>'
                r = re.findall(r''+pattern+'', str(href), re.I)
                print r
                totalitems = len(r)
                for url, name in r:
                    t = grab.get_meta('tvshow', name.strip(), '', '', '', overlay=6) 
                    addDir(100, url, '', 'Latest Added Shows', name, t['banner_url'], totalitems, True)
            #    xbmc.executebuiltin("Container.SetViewMode(500)" )
    r =  re.findall(r'New Series', title, re.I)
    if not r:
        r = re.findall('href=\"(.+?)(?=\".+?Older posts)', str(soup), re.I)
        for npUrl in r:
            print '====================='
            print npUrl
            addDir(100, npUrl, title, 'Latest Added Shows','[COLOR green][B]Next Page>>>[/COLOR][/B]',
                   os.path.join(art, 'np.jpg'), 0, True)
    if local.getSetting("usemeta") == "true": setView('episodes', 'episode')
    else:
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmc.executebuiltin("Container.SetViewMode(500)" )             

    
def FindStreams(url,types):
    try:
        html = net().http_GET(url).content
    except:
        print html

    r = re.findall(r"Watch Online:(.+?)<a href='http://www.affbu",html,re.DOTALL|re.M|re.I)
    r = str(r).replace('|',' ')
    r = re.findall(r'href="(.+?)">(.+?)</a>',str(r),re.DOTALL)
    if int(len(r)) <= 3:
        for url, hoster in r:
            name = '[B][COLOR green]'+hoster+'[/B][/COLOR]'
            addDir(200,url, '', types, name, os.path.join(art, hoster+'.jpg'), 0, '')
    if (len(r) >= 6):
        post_pattern = r"<b><u>Watch Online:</b></u>(.+?)<a href='http://www.affbu"
        for post in re.finditer(post_pattern, html, re.DOTALL|re.M):
            content_pattern = r'\W?((?:[\w\.-])+)<br.+?href="(.+?)">(\w+)<.+?href="(.+?)">(\w+)<.+?href="(.+?)">(\w+)<'
            content = re.finditer(content_pattern, post.group(1), re.DOTALL)
 
        media = []
        for item in content:
            title, link1, host1, link2, host2, link3, host3 = item.groups()
            title = str(title.replace('.',' '))
            media.append((('[B][COLOR green]'+host1+'[/B][/COLOR]', title+'|'+link1), ('[B][COLOR green]'+host2+'[/B][/COLOR]', title+'|'+link2), ('[B][COLOR green]'+host3+'[/B][/COLOR]', title+'|'+link3)))
        image = types+'!'+title
        for item in media:
            for info_set in item:
                name = "".join(str(info_set)).strip('[]')
                r = name.split('|')
                name = r[0].replace("(u'",'').replace("', u'",' ').replace("')","")
                hoster = re.findall('een\](.+?)\[\/', name)[0].lower()
                url = r[1].replace("')",'')
                addDir(200, url, '', image, name, os.path.join(art, hoster+'.jpg'), 0, '')
        




def ResolveStreams(url,types):
    if '!' in types:
        title = types.rpartition('!')[2]
        img = types.rpartition('#')[0]
    else:
        img = types.rpartition('#')[0]
        title = types.rpartition('#')[2]
    if '.any.gs/url/' in url:url = re.findall(r'any.gs/url/(\S+)', url, re.I)[0]
    r = re.findall('putlocker', url, re.I)
    if not r:
        media_url = urlresolver.resolve(url)
    if r:
        html = net().http_GET(url).content
        pattern = '<a href="(/.+?)" class="download_file_link" style="margin:0px 0px;">Download File</a>'
        link = re.search(pattern, html)
        if link:
            print 'Direct link found: %s' %link.group(1)
            return 'http://www.putlocker.com%s' %link.group(1)

        r = re.search('value="([0-9a-f]+?)" name="hash"', html)
        if r:
            session_hash = r.group(1)
        else:
            common.addon.show_small_popup(title='[B][COLOR white]PUTLOCKER[/COLOR][/B]', msg='[COLOR red]No such file or the file has been removed[/COLOR]', delay=8000, image=error_logo)
            common.addon.log_error('putlocker: session hash not found')
            

        #post session_hash
        try:
            html = net().http_POST(url, form_data={'hash': session_hash, 
                                                           'confirm': 'Continue as Free User'}).content
        except urllib2.URLError, e:
            common.addon.log_error('putlocker: got http error %d posting %s' %(e.code, web_url))
            
        
        #find playlist code  
        r = re.search('\?stream=(.+?)\'', html)
        if r:
            playlist_code = r.group(1)
        else:
            r = re.search('key=(.+?)&',html)
            playlist_code = r.group(1)
        
        if 'putlocker' in url:
            Avi = "http://putlocker.com/get_file.php?stream=%s&original=1"%playlist_code
            html = net().http_GET(Avi).content
            final=re.compile('url="(.+?)"').findall(html)[0].replace('&amp;','&')
            media_url = "%s|User-Agent=%s"%(final,'Mozilla%2F5.0%20(Windows%20NT%206.1%3B%20rv%3A11.0)%20Gecko%2F20100101%20Firefox%2F11.0')
        
    if media_url:
        liz=xbmcgui.ListItem(title, iconImage= '', thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels={ "Title": title} )
        liz.setProperty("IsPlayable","true")
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=media_url, addon_id=addonID, video_type='', title=title.title(),
                                                            season='', episode='', year='', watch_percent=0.9, watchedCallback='',
                                                            watchedCallbackwithParams=None, imdb_id=None, img=img, fanart='', infolabels='')
        player.KeepAlive()
    else:
        print 'OFFER SEARCH'
    

def GRABMETA(metaname, types):
    if re.findall(r'\(\d+X\d+\)', metaname, re.I):
        r = re.search(r'(.+?)\s\((\d+)X(\d+)\)', metaname, re.I).groups()
        name = r[0].strip()
        t = grab.get_meta('tvshow', r[0].strip(), '', '', '', overlay=6)
        meta = grab.get_episode_meta(r[0].strip(), t['imdb_id'],r[1].strip(),r[2].strip(),air_date='', episode_title='', overlay='')
        #if meta['backdrop_url'] == '':meta['backdop_url']= os.path.join( local.getAddonInfo('path'), 'fanart.jpg')
    if re.findall('\sseason\s\d+\sepisode\s\d+', metaname, re.I):
        r = re.search('(.+?)\sseason\s(\d+)\sepisode\s(\d+)', metaname, re.I).groups()
        t = grab.get_meta('tvshow', r[0].strip(), '', '', '', overlay=6)
        meta = grab.get_episode_meta(r[0].strip(), t['imdb_id'],r[1].strip(),r[2].strip(),air_date='', episode_title='', overlay='')
        
    else:meta = {'cover_url': '','title': metaname, 'backdrop_url': os.path.join( local.getAddonInfo('path'), 'fanart.jpg')}
    #if  meta['backdrop_url'] == '':meta['backdop_url']= os.path.join( local.getAddonInfo('path'), 'fanart.jpg')
    print meta
    return meta
                                     
        
    

        

def CleanName(url):
    print 'CleanName'
    print url
    try:name = url[:-1].rpartition('/')
    except:pass
    name = str(name[2]).replace('-', ' ')
    print name
    r = re.findall(r'(.+?episode\s\d+)', str(name), re.I)
    if r:
        name = str(r[0]).strip()
        return name
    if not r:
        return name
    

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )

    
        
    
    

def addDir( mode, url, metaname, types, name, img, totalitems, folder):
    u  = sys.argv[0]
    u += "?mode="       + str(mode)
    u += "&url="        + str(url)
    u += "&metaname="   + str(metaname)
    u += "&types="      + str(types)
    u += "&name="       + str(name)
    u += "&img="        + str(img)
    u += "&totalitems=" + str(totalitems)
    u += "&folder="     + str(folder)
    if local.getSetting("usemeta") == "true" and metaname != '':
        infoLabels = GRABMETA(metaname, types)
        try:img = infoLabels['banner_url']
        except:pass
    else: infoLabels = {'cover_url': img, 'title': name}
    ok = True
    liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage=img)
    try:
        if infoLabels['backdrop_url'] == '':infoLabels['backdrop_url'] = os.path.join( local.getAddonInfo('path'), 'fanart.jpg')
        liz.setProperty('fanart_image', infoLabels['backdrop_url'])
    except:liz.setProperty('fanart_image', os.path.join( local.getAddonInfo('path'), 'fanart.jpg'))
    liz.setInfo(type="Video", infoLabels=infoLabels)
    if folder == True:ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,
                                                     totalItems=int(totalitems))
    else:ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]
        return param

params     = get_params()
mode       = None
url        = None
metaname   = None
types      = None
name       = None
img        = None
totalitems = None
folder     = None

try: mode = int(params['mode'])
except:pass
try: url = urllib.unquote_plus(params["url"])
except:pass
try: metaname = urllib.unquote_plus(params["metaname"])
except:pass
try: types = urllib.unquote_plus(params["types"])
except:pass
try: name = urllib.unquote_plus(params["name"])
except:pass
try: img = urllib.unquote_plus(params["img"])
except:pass
try:totalitems = int(params["totalitems"])
except:pass
try: folder = urllib.unquote_plus(params["folder"])
except:pass

xbmc.log('Mode: '+str(mode))
xbmc.log('Url: '+str(url))
xbmc.log('Metaname: '+str(metaname))
xbmc.log('Types: '+str(types))
xbmc.log('Name: '+str(name))
xbmc.log('Img: '+str(img))
xbmc.log('Folder: '+str(folder))

if mode == None or url == None or len(url)<1:
    MAIN()
elif mode == 10: urlresolver.display_settings()
elif mode == 100:FindShows(url,name)
elif mode == 101:Newseries(url)
elif mode == 150:FindStreams(url,types)
elif mode == 200:ResolveStreams(url,types)

xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=True)

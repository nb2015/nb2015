addon_id="script.icechannel.einthusan.settings"
addon_name="iStream - einthusan - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()

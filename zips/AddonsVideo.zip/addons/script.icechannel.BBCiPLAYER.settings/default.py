addon_id="script.icechannel.BBCiPLAYER.settings"
addon_name="iStream - BBC iPLAYER - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()

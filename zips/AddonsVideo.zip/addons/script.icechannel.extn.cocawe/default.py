addon_id="script.icechannel.extn.cocawe"
addon_name="Cocawe's iStream Extension"
